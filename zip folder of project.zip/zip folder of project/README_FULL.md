
# 💊 Smart Health Console App — Java Project

> ⚡ **“Digitizing Healthcare — One Console at a Time.”**  
> 🎓 _Developed by Roshan Kushwaha_  
> 🏫 Galgotias University | 🚀 GUVI Java Project Submission

---

## 🧠 Project Summary

The **Smart Health Console App** is a Java-based, menu-driven healthcare management system designed to help hospitals or clinics manage their core data:

- 👤 Patients  
- 👨‍⚕️ Doctors  
- 📅 Appointments  

It uses **file-based storage** and **Object-Oriented Programming** to simulate a real-world clinic system through console interaction.

---

## 🎯 Features — Explained in Depth with Code & Output

### 1️⃣ Patient Management System

#### ✅ Add, View, Update, Delete Patients  
Each patient has:
- ID (auto-generated)
- Name, Age, Gender, Contact

**Code Example**:
```java
patientService.addPatient("Rahul Sharma", 25, "Male", "9876543210");
```

**Console Output**:
```
Patient added successfully with ID: 1
```

---

### 2️⃣ Doctor Management System

#### ✅ Add, View, Update, Delete Doctors  
Fields:
- ID (auto-generated)
- Name, Specialization, Contact

**Code Example**:
```java
doctorService.addDoctor("Dr. Meena Singh", "Cardiologist", "9876543211");
```

**Console Output**:
```
Doctor added successfully with ID: 1
```

---

### 3️⃣ Appointment Scheduling

#### ✅ Book, Update, Cancel, List Appointments  
Appoints a patient with a doctor using date and time.

**Code Example**:
```java
appointmentService.addAppointment(1, 1, "2025-06-10", "11:30");
```

**Console Output**:
```
Appointment scheduled successfully with ID: 1
```

---

### 4️⃣ Input Validation (Robust Data Entry)

✔ Name should be alphabetic  
✔ Age must be 1–119  
✔ Contact = exactly 10 digits  
✔ Date in `YYYY-MM-DD` format  
✔ Time in `HH:MM`

**Code Example**:
```java
if (!InputValidator.isValidName(name)) {
    System.out.println("Invalid name.");
}
```

---

### 5️⃣ File-Based Persistence (No Database Needed)

All data is saved to `.txt` files in the `/data/` directory.

**Files:**
- `patients.txt`
- `doctors.txt`
- `appointments.txt`

**File Sample Content** (`patients.txt`):
```
1,Rahul Sharma,25,Male,9876543210
```

---

### 6️⃣ Console UI Navigation

**Main Menu:**
```
=== Smart Health Console App ===
1. Patient Management
2. Doctor Management
3. Appointment Management
4. Exit
```

**Submenus** include options like:
- Add, Update, Delete, List

✅ Fully menu-driven with clean navigation.

---

## 📂 Project Structure

```
SmartHealthApp/
├── src/
│   └── SmartHealthApp.java
├── data/
│   ├── patients.txt
│   ├── doctors.txt
│   └── appointments.txt
├── README.md
├── .gitignore
└── LICENSE
```

---

## 🚀 How to Run It

1. Clone the repo:
```bash
git clone https://github.com/your-username/SmartHealthApp.git
cd SmartHealthApp
```

2. Compile the source code:
```bash
javac src/SmartHealthApp.java
```

3. Launch the application:
```bash
java -cp src SmartHealthApp
```

---

## 🔮 Planned Future Enhancements

- 🔍 Search patients by name
- 📤 Export reports to CSV
- 🖼️ Add JavaFX-based GUI
- 📈 Analytics for appointments

---

## 💡 Technologies Used

- Java 8+
- File I/O (BufferedReader & Writer)
- Collections API
- OOP Design
- Console-based Interaction

---

## 🧑‍💻 About the Author

**Roshan Kushwaha**  
_Galgotias University Java Developer | GUVI Project Star_  
📧 roshan@example.com  
🌐 [GitHub Profile](https://github.com/your-username)

---

## 📜 License

This project is licensed under the [MIT License](LICENSE)

> _“Created with 💖, powered by ☕, reviewed with 🧠”_
